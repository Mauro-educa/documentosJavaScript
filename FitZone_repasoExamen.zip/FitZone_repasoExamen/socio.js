
import { Persona } from "./persona.js";

export class Socio extends Persona{
    #actividades=[];
    constructor(nombre,apellidos,dni,telefono,actividades){
        this.#actividades=actividades;
        super(nombre,apellidos,dni,telefono);

    }
    reservarClase(numeroClase){
        return "el socio "+super(nombre)+" reserva la clase "+numeroClase;
    }
    set Actividades(valor){
        this.#actividades.push(valor);
    }
     get Actividades(){
      return  this.#actividades;
    }
}
