import { Carrera } from "./carrera.js";
export class CalendarioCarreras {

    #carreras = [new Map()];

    constructor() {

    }
    anadirCarrera(carrera) {
        this.#carreras.forEach(ca => {
            if (ca.Fecha == carrera.Fecha) {
                console.log("Ya existe una carrera en ese dia")
                return false;
            }
        })
        this.#carreras.set(carrera.Nombre, carrera);
        console.log("carrera " + carrera.Nombre + " añadida")
        return true;
    }
    consultarListadoCarreras() {
        console.log("orden de registro  carrera barrio fecha indicada fecha asignada")
        let arrCarreras = [[], []];
        let carrera = []
        this.#carreras.forEach((ca, i) => {
            carrera = [];
            carrera.push(i);
            carrera.push(ca.Nombre);
            carrera.push(ca.Barrio);
            carrera.push(ca.FechaIndicada);
            carrera.push(ca.FechaAsignada);
            ca.listarEquipos();
        })
        arrCarreras.push(carrera);
        console.table(arrCarreras);
    }

    consultarListadoCarrerasBarrio() {
        let arrCarreras = [[], []];
        console.log(" barrio fecha nombre  ");
        let carrera = []
        this.#carreras.map(ca => {
            carrera = [];
            carrera.push(ca.Barrio); carrera.push(ca.FechaAsignada); carrera.push(ca.Nombre)

        })
        arrCarreras.push(carrera);
        console.table(arrCarreras);
    }

}


