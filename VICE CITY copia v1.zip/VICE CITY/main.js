import {Carrera} from "./carrera.js";
import {Equipo} from "./equipo.js";
import {CalendarioCarreras} from "./calendarioCarreras.js";
import {Piloto} from "./piloto.js";

let piloto1=new Piloto("Manolo","Garcia","velocidad");
let piloto2=new Piloto("Pepe","Juarez","derrape");

let equipo1= new Equipo(piloto1,piloto2,"lema de vice city");
 let carrera1=new Carrera("carrera de la playa","puerto","000");
 carrera1.inscribirEquipo(equipo1);
 carrera1.garajeMapa(1,2,equipo1);

 let calendario1=new CalendarioCarreras();
 calendario1.anadirCarrera(carrera1);
 calendario1.consultarListadoCarreras();
 calendario1.consultarListadoCarrerasBarrio();
console.log(equipo1.calcularMatricula());
console.log(equipo1.calcularNombreClave());
console.log(equipo1.nivelBusqueda("exceso de velocidad"));
console.log(equipo1.premioNeto());